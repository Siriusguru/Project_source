/** Automatically generated file. DO NOT MODIFY */
package exam.project;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}